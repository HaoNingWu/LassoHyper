function [integral,CL_npunti]=GCL3(n,f)
%---------------------------------------------------
% This function compute the integral of f on [-1,1]^3
% by the tensor product Gauss-Chebyshev-Lobatto formula
% ---------------------------------------------------
%  Authors: 
%      Stefano De Marchi
%      Department of Computer Science
%      University of Verona
%   
%      Marco Vianello
%      Department of Pure and Applied Math.
%      University of Padova
%      
% Version: May 2008
%----------------------------------------------------
% 1d Chebyshev
 ab=r_jacobi(n,-.5,-.5);
 xw=lobatto(n-2,ab,-1,1);  % xw is a 2 columns array: 
                    % the first contains the points; 
                    % the second gives the weights.
[X,Y,Z]=ndgrid(xw(:,1));
[Wx,Wy,Wz]=ndgrid(xw(:,2));
W=[Wx(:),Wy(:),Wz(:)];
WW=W(:,1).*W(:,2).*W(:,3);
FC=f(X,Y,Z);

FF=reshape(FC,n^3,1);
CL_npunti=n^3;
integral=WW'*FF;
return
