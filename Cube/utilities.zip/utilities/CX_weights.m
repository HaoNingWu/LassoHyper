function [F,W,integral]= CX_weights(n,f,c,V,JU)
% ------------------------------------------
%  M-function that allows to 
%  compute the cubature/interpolation weights
%  and the value of the integral
%
% inputs: n=degree; f=array of function values;
%         c=Chebyshev points in [-1,1]; 
%         V=points in the cube (3d array)
%
% outputs: F=3d structure, (n+1)x(n+1)x(n+1), 
%            containing the values fo f
%          W=the cubature/interpolation weights
%          integral= the approximate value of the
%                    integral obtained as the normalized 
%                    scalar product of W and f at the 
%                    points in the cube.
% --------------------------------------------
%  Authors: 
%      Stefano De Marchi
%      Department of Computer Science
%      University of Verona
%   
%      Marco Vianello
%      Department of Pure and Applied Math.
%      University of Padova
%      
% Version: May 2008
% -----------------------------------------
W=4/n^3*ones(size(V,1),1);

Jfaces=find((V(:,1)==c(1) | V(:,1)==c(end))| (V(:,2)==c(1) | V(:,2)==c(end)) | (V(:,3)==c(1) | V(:,3)==c(end))  );
W(Jfaces)=1/2*W(Jfaces); %weights on faces

Jedges=find(( (V(:,1)==c(1) | V(:,1)==c(end)) & (V(:,2)==c(1) | V(:,2)==c(end))) |  ...
  ((V(:,1)==c(1) | V(:,1)==c(end)) & (V(:,3)==c(1) | V(:,3)==c(end))) |  ...    
((V(:,2)==c(1) | V(:,2)==c(end)) & (V(:,3)==c(1) | V(:,3)==c(end)) ));
W(Jedges)=1/2*W(Jedges); %weights on edges

Jvertices=find(( (V(:,1)==c(1) | V(:,1)==c(end)) & (V(:,2)==c(1) | V(:,2)==c(end))) & (V(:,3)==c(1) | V(:,3)==c(end)) );
W(Jvertices)=1/2*W(Jvertices); %weights on vertices

f(JU)=W.*f(JU);
F=reshape(f,n+1,n+1,n+1);

integral=(pi^3)*sum(sum(sum(F))); %this is the value of the intergral in the 
                                  %Chebyshev measure

return