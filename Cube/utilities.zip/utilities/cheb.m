function y=cheb(x,n)
% Compute the Chebyshev polynomials
% -----------------------------------------
% Authors: 
%      Stefano De Marchi
%      Department of Computer Science
%      University of Verona
%   
%      Marco Vianello
%      Department of Pure and Applied Math.
%      University of Padova
%      
% Version: May 2008
% -----------------------------------------
y=cos([0:n]'*acos(x));
return
