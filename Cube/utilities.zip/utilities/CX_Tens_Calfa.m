function [Calfa,M,Calfa1]=CX_Tens_Calfa(F,n)
%----------------------
% FFT of the F values
%----------------------

C=real(fft(real(fft(real(fft(F,2*n,3)),2*n,2)),2*n,1));

% array of indices

[Mx,My,Mz]=ndgrid(1:n+1);
M=[Mx(:) My(:) Mz(:)];
C1=C(1:n+1,1:n+1,1:n+1);
CC1=reshape(C1,(n+1)^3,1);

% scaling the coefficients

PC1=find(M(:,1) ~= 1);
CC1(PC1)=sqrt(2)*CC1(PC1);
PC2=find(M(:,2) ~= 1);
CC1(PC2)=sqrt(2)*CC1(PC2);
PC3=find(M(:,3) ~= 1);
CC1(PC3)=sqrt(2)*CC1(PC3);

P1=find(M(:,1)+M(:,2)+M(:,3) >= n+1 &  M(:,1)+M(:,2)+M(:,3) <= n+2 );

Calfa=CC1;  % The coefficients
Calfa1=CC1(P1);
return
