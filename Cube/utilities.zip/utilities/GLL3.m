function [integral,GL_npunti]=GLL3(n,f)
%------------------------------------------------------
% This function compute the integral of f on [-1,1]^3
% by the tensor product Gauss-Legendre-Lobatto formula.
% -----------------------------------------------------
%  Authors: 
%      Stefano De Marchi
%      Department of Computer Science
%      University of Verona
%   
%      Marco Vianello
%      Department of Pure and Applied Math.
%      University of Padova
%      
% Version: May 2008
%-------------------------------------------------------
deg=n;
ab=r_jacobi(deg);
xw=lobatto(deg-2,ab,-1,1);  % xw is a 2 columns array: 
                            % the first contains the points; 
                            % the second gives the weights.
[X,Y,Z]=ndgrid(xw(:,1));
[Wx,Wy,Wz]=ndgrid(xw(:,2));
W=[Wx(:),Wy(:),Wz(:)];
WW=W(:,1).*W(:,2).*W(:,3);
FC=f(X,Y,Z);
FF=reshape(FC,deg^3,1);
GL_npunti=deg^3;
integral=WW'*FF;
return
