function [C0,est] = xu2(n,xi1,xi2,wxi,f)
% [C0, est] = xu2(n, xi1, xi2, wxi, f)
%
% Hyperinterpolation coefficients
%
% n      = hyperinterpolation degree
% xi1    = the x values of Xu points.
% xi2    = the y values of Xu points.
% wxi    = the weights associated to each Xu point.
% f      = function values at Xu points
%
% C0     = coefficients matrix
% est    = estimated error
[Txi1,Txi2] = cheb2(n,xi1,xi2);
% Valuto la funzione sui punti generati, normalizzati nell'intervallo
% di definizione della funzione. Aggiungo un offset per centrarli
% nell'intervallo d'interesse.
C0=Txi1.*repmat(wxi.*f,n+1,1)*Txi2';
C0=fliplr(C0);
est=2*(norm(diag(C0),1)+norm(diag(C0,1),1)+norm(diag(C0,2),1));
C0=fliplr(triu(C0));
