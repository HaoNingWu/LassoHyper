function [our_npoints,err_quad]=CX_Cubature(n,Val_exact,fam)
% ----------------------------------------
%  This function allows to compute integrals
%  by the non-tensor Clenshaw-Curtis formula with the
%  Lebesgue measure in the cube
%
% inputs: n=degree
%         Val_exact=the exact value of the integral
%         fam=paramter that allows to choose one of the 4 sub-grids listed
%         below
% 
% outputs: our_npoints=number of points used
%          err_quad=relative abs error 
% 
%  Authors: 
%      Stefano De Marchi
%      Department of Computer Science
%      University of Verona
%   
%      Marco Vianello
%      Department of Pure and Applied Math.
%      University of Padova
%      
% Version: May 2008
% -----------------------------------------

                           
c=cos([0:n]*pi/n);     % Chebsyhev points
[X,Y,Z]=ndgrid(c);     % 3d grid of Chebsyhev points in the cube
Sc=[X(:), Y(:), Z(:)]; % this is the Chebyshev grid arranged as an array with 3 coordinates

% Here we extract the sub-vector E=EVEN and O=ODD of the Chebsyhev points 
E=c(1:2:length(c));
O=c(2:2:length(c));

%----------------------------------------
% generation of the sub-grids 
%
% We have 4 possible choices
% 1) EEE OOO
% 2) EOO OEE
% 3) OEE EOO
% 4) EOE OEO
%----------------------------------------

switch(fam)
    case 1
[X1,Y1,Z1]=meshgrid(E,E,E);
[X2,Y2,Z2]=meshgrid(O,O,O);
    case 2
[X1,Y1,Z1]=meshgrid(E,E,O);
[X2,Y2,Z2]=meshgrid(O,O,E);

    case 3
[X1,Y1,Z1]=meshgrid(E,O,O);
[X2,Y2,Z2]=meshgrid(O,E,E);
    case 4
[X1,Y1,Z1]=meshgrid(O,O,O);
[X2,Y2,Z2]=meshgrid(E,E,E);
end

EEE=[X1(:),Y1(:),Z1(:)];
OOO=[X2(:),Y2(:),Z2(:)];
U=[EEE;OOO];
our_npoints=size(U,1);

[MU,IU]=setdiff(Sc,U,'rows'); % indices of the points of product Chebyshev-Lobatto grid
                              % which are not Xu points on the Cube
                              % Chebyshev-Lobatto che non sono di Xu sul cubo
    
% The function at the Xu points and zero elsewhere 
LSc=length(Sc(:,1));
f=zeros(LSc,1);
JU=setdiff(1:LSc,IU);
V=Sc(JU,:);  %punti di Xu in 3D
[f(JU),f_name]=fCube(V(:,1),V(:,2),V(:,3));
%ff=f;

%------------------------------------------
% compute the weights W and the structure F
%-------------------------------------------

[F,W]= CX_weights(n,f,c,V,JU);

%-------------------------------
% Compute the coefficients Calfa
% ------------------------------
[Calfa,M,P]=CX_Calfa(F,n);  

%tempi(n-n0+1)=toc;
%--------------------
%   Cubature 
%--------------------

ind=M(P,:); % matrix of indices

% Chebyshev moments computation
ii=3:n;
mom(1)=2;
mom(2)=0;
mom(3:n)=2*sqrt(2)./(1-(ii-1).^2).*abs((rem((ii-1),2)==0));
mom3d=mom(ind(:,1)).*mom(ind(:,2)).*mom(ind(:,3));
integral=mom3d*Calfa;
err_quad=abs(integral-Val_exact)/abs(Val_exact);











