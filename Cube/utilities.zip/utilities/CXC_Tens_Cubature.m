function [GC_npunti,err_quad_GC,GCL_npunti,err_quad_GCL]=CXC_Tens_Cubature(n,Val_exact)
%-------------------------------------------------
%  This function allows to compute integrals
%  by the tensor-product Gauss-Chebsyhev and
%  tensor-product Gauss-Chebsyhev-Lobatto formulae
%  in the cube
%
% inputs: n=degree
%         Val_exact=the exact value of the integral
% 
% outputs: *_npoints=number of points used
%          err_quad_*=relative abs errors 
% 
% -----------------------------------------
%  Authors: 
%      Stefano De Marchi
%      Department of Computer Science
%      University of Verona
%   
%      Marco Vianello
%      Department of Pure and Applied Math.
%      University of Padova
%      
% Version: May 2008
% -----------------------------------------

% Tensor-product Gauss-Chebsyhev formulae
[GCintegral,GC_npunti]=GC3(n,@fCube);
% Tensor-product Gauss-Chebyshev-Lobatto formulae
[GCLintegral,GCL_npunti]=GCL3(n,@fCube);

%------------------
%   Compute errors 
%-----------------

% Tensor-product Gauss-Chebsyhev
err_quad_GC=abs(GCintegral-Val_exact)/abs(Val_exact);

% Tensor-product Gauss-Chebsyhev-Lobatto
err_quad_GCL=abs(GCLintegral-Val_exact)/abs(Val_exact);







