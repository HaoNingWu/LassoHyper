
function [err_TI, errest_TI, LSc, m, Ltime,f_name]=CX_Tens_Interpolation(n,f_idx)
%--------------------------------------------------------------------------
%  M-function that allows to compute the 
%  tensor product interpolant on the cube
% -----------------------------------------------------------------
% input: n=degree
% outputs: err_TI=rel abs tensor-product interpolation error
%          errest_I=estimate tens-product interpolatio error
%          LSc=function evaluations
%          m=the number of coefficients Calfa, length(Calfa);
%          Ltime=cputime
%          fname=function name
%------------------------------------------------------------------------
%  Authors: 
%      Stefano De Marchi
%      Department of Computer Science
%      University of Verona
%   
%      Marco Vianello
%      Department of Pure and Applied Math.
%      University of Padova
%      
% Version: May 2008
% -----------------------------------------
%---- Grid of target points ------------
mm=5;
targets=linspace(-1,1,mm);     
[xix,xiy,xiz]=meshgrid(targets);
Ptar=[xix(:) xiy(:) xiz(:)];
%--------------------------------------


t=cputime;
c=cos([0:n]*pi/n);     % Chebsyhev points
[X,Y,Z]=ndgrid(c);     % 3d grid of Chebsyhev points in the cube
Sc=[X(:), Y(:), Z(:)]; % this is the Chebyshev grid arranged as an array with 3 coordinates
LSc=length(Sc(:,1));
                         
% The function on the tensor product Chebyshev points
% [f,fname]=fCube(Sc(:,1), Sc(:,2), Sc(:,3));

x=Sc(:,1); y=Sc(:,2);z=Sc(:,3);
switch f_idx
    case 1
        f = exp(-(x.^2+y.^2+z.^2));
        f_name='exp(-(x^2+y^2+z^2))';
    case 2
        f=1./(1+16*(x.^2+y.^2+z.^2));
        f_name='1/(1+16(x^2+y^2+z^2))';
    case 3
        f = sqrt((x.^2+y.^2+z.^2)).^3;
        f_name='(x^2+y^2+z^2)^{3/2}';
    case 4
        f = exp(abs(x+y+z));
        f_name='exp(|x+y+z|)';
    case 5
        f = exp(-1./(x.^2+y.^2+z.^2));
        f_name='exp(-1/(x^2+y^2+z^2))';
end


f(find(f~=0)) = noisegen(f(find(f~=0)),10);


%----------------------
% compute the weights
%----------------------
[F,W]= CX_Tens_weights(n,f,c,Sc);

%-------------------------------
% Compute the coefficients Calfa
% ------------------------------

[Calfa,M,Calfa1]=CX_Tens_Calfa(F,n);
errest_TI=sum(abs(Calfa1));
% ----------------------------------
% Construction of the interpolant
%----------------------------------

%---- Interpolation on a grid of target points ------------

scaling=[1,ones(1,n)*sqrt(2)]';  % scaling for Chebyshev polynomials

m=length(Calfa);
D=diag(scaling);

TX=D*cheb(Ptar(:,1)',n);
TY=D*cheb(Ptar(:,2)',n);
TZ=D*cheb(Ptar(:,3)',n);


%Palfa=(D*cheb(Ptar(ind(1:m,1),1)',n)).*(D*cheb(Ptar(ind(1:m,2),2)',n)).*(D*cheb(Ptar(ind(1:m,3),3)',n));

Palfa=TX(M(:,1),:).*TY(M(:,2),:).*TZ(M(:,3),:);
L=Palfa'*Calfa; % the vector containing the values of the interpolant 

% f_targets=fCube(Ptar(:,1),Ptar(:,2),Ptar(:,3));
x=Ptar(:,1); y=Ptar(:,2);z=Ptar(:,3);
switch f_idx
    case 1
        f_targets = exp(-(x.^2+y.^2+z.^2));
    case 2
        f_targets=1./(1+16*(x.^2+y.^2+z.^2));
    case 3
        f_targets = sqrt((x.^2+y.^2+z.^2)).^3;
    case 4
        f_targets = exp(abs(x+y+z));
    case 5
        f_targets = exp(-1./(x.^2+y.^2+z.^2));
end
f_mean=sum(f_targets)/length(Ptar(:,1));

err_TI=norm(L-f_targets, inf);%/max(abs(f_targets-f_mean));  % rel error in infinity norm

Ltime=cputime-t;
return

