function [integral,GL_npunti]=GL2(n,f)
%---------------------------------------------------
% This function compute the integral of f on [-1,1]^2
% by the tensor product Gauss Legendre formula.
%----------------------------------------------------
deg=n;
ab=r_jacobi(deg);
xw=lobatto(deg-2,ab,-1,1);  % xw is a 2 columns array: 
                          % the first contains the points; 
                          % the second gives the weights.
[X,Y]=ndgrid(xw(:,1));
[Wx,Wy]=ndgrid(xw(:,2));
W=[Wx(:),Wy(:)];
WW=W(:,1).*W(:,2);
FC=f(X,Y);
FF=reshape(FC,deg^2,1);
GL_npunti=deg^2;
integral=WW'*FF;
return
