
function [GL_npunti,err_quad_GL,GLL_npunti,err_quad_GLL,...
    CC_npunti,err_quad_CC]=CX_Tens_Cubature(n,Val_exact)
%----------------------------------------------------------
%  This function allows to compute integrals
%  by the tensor-product Gauss-Legendre and
%  tensor-product Gauss-Legendre-Lobatto formulae
%  in the cube
%
% inputs: n=degree
%         Val_exact=the exact value of the integral
% 
% outputs: *_npoints=number of points used by a formula
%          err_quad_*=relative abs error computed for
%                     a formula
% 
% ---------------------------------------------------------
%  Authors: 
%      Stefano De Marchi
%      Department of Computer Science
%      University of Verona
%   
%      Marco Vianello
%      Department of Pure and Applied Math.
%      University of Padova
%      
% Version: May 2008
% ---------------------------------------------------------

% Tensor-product Gauss-Legendre formulae
[GLintegral,GL_npunti]=GL3(n,@fCube);
err_quad_GL=abs(GLintegral-Val_exact)/abs(Val_exact);

% Tensor-product Gauss-Legendre-Lobatto formulae
[GLLintegral,GLL_npunti]=GLL3(n,@fCube);
err_quad_GLL=abs(GLLintegral-Val_exact)/abs(Val_exact);

% Tensor-product Clenshaw-Curtis formulae
[CCintegral,CC_npunti]=CC3(n,@fCube);
err_quad_CC=abs(CCintegral-Val_exact)/abs(Val_exact);



 





