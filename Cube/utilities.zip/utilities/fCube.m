function [f,f_name]=fCube(X,Y,Z)
%---------------------------------------------
% This functions provides all the 
% test functions used for numerical 
% experiments
%
% inputs: X,Y,Z=the meshgrid of 3d points
% outputs: f=the function values at X,Y,Z
%          f_name=the string cointaining the 
%                 function expression
% ---------------------------------------------
% Authors: 
%      Stefano De Marchi
%      Department of Computer Science
%      University of Verona
%   
%      Marco Vianello
%      Department of Pure and Applied Math.
%      University of Padova
%      
% Version: May 2008
% --------------------------------------------      

x=X; y=Y;z=Z;

% These are the linear transformations
% for the cube [0,1]^3
%  x=(X+1)/2;
%  y=(Y+1)/2;
%  z=(Z+1)/2;

% TEST FUNCTIONS for QUADRATURE
% F1
%  f=exp(-(x.^2+y.^2+z.^2));
%  f_name='exp(-(x^2+y^2+z^2))';

% F2
% f=1./(1+16*(x.^2+y.^2+z.^2));
% f_name='1/(1+16(x^2+y^2+z^2))';

% F3
f=sqrt((x.^2+y.^2+z.^2)).^3;
f_name='(x^2+y^2+z^2)^{3/2}';
 
% F4
% f=(x+y+z).^(20);
% f_name='(x+y+z)^{20}';

% F5  
% f=exp(x+y+z);
% f_name='exp(x+y+z)';

% F6
%   f=exp(-1./(x.^2+y.^2+z.^2));
%   f_name='exp(-1/(x^2+y^2+z^2))';


end
