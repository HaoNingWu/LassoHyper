function [integral]= CX_integral(n,f)
% ------------------------------------------
%  M-function that allows to 
%  compute the cubature/interpolation weights
%  and the value of the integral
%
% inputs: n=degree; f=array of function values;
%         c=Chebyshev points in [-1,1]; 
%         V=points in the cube (3d array)
%
% outputs: F=3d structure, (n+1)x(n+1)x(n+1), 
%            containing the values fo f
%          W=the cubature/interpolation weights
%          integral= the approximate value of the
%                    integral obtained as the normalized 
%                    scalar product of W and f at the 
%                    points in the cube.
% --------------------------------------------
%  Authors: 
%      Stefano De Marchi
%      Department of Computer Science
%      University of Verona
%   
%      Marco Vianello
%      Department of Pure and Applied Math.
%      University of Padova
%      
% Version: May 2008
% -----------------------------------------
c=cos([0:n]*pi/n);     % Chebsyhev points
[X,Y,Z]=ndgrid(c);     % 3d grid of Chebsyhev points in the cube
Sc=[X(:), Y(:), Z(:)]; % this is the Chebyshev grid arranged as an array with 3 coordinates

% Here we extract the sub-vectors E=EVEN and O=ODD of Chebsyhev-Lobatto points 
E=c(1:2:length(c));
O=c(2:2:length(c));

[X1,Y1,Z1]=meshgrid(O,E,E);
[X2,Y2,Z2]=meshgrid(E,O,O);

EEE=[X1(:),Y1(:),Z1(:)];
OOO=[X2(:),Y2(:),Z2(:)];
U=[EEE;OOO];
%our_npunti(n-n0+1)=size(U,1);

[MU,IU]=setdiff(Sc,U,'rows'); % indeces of the points of product Chebyshev-Lobatto grid
                              % which arae not Xu points on the Cube
                         
% The function on the Xu points and zero elsewhere 
LSc=length(Sc(:,1));
JU=setdiff(1:LSc,IU);
V=Sc(JU,:);  % Xu points on the cube in 3D
% [f(JU),fname]=fCube(V(:,1),V(:,2),V(:,3));




W=4/n^3*ones(size(V,1),1);

Jfaces=find((V(:,1)==c(1) | V(:,1)==c(end))| (V(:,2)==c(1) | V(:,2)==c(end)) | (V(:,3)==c(1) | V(:,3)==c(end))  );
W(Jfaces)=1/2*W(Jfaces); %weights on faces

Jedges=find(( (V(:,1)==c(1) | V(:,1)==c(end)) & (V(:,2)==c(1) | V(:,2)==c(end))) |  ...
  ((V(:,1)==c(1) | V(:,1)==c(end)) & (V(:,3)==c(1) | V(:,3)==c(end))) |  ...    
((V(:,2)==c(1) | V(:,2)==c(end)) & (V(:,3)==c(1) | V(:,3)==c(end)) ));
W(Jedges)=1/2*W(Jedges); %weights on edges

Jvertices=find(( (V(:,1)==c(1) | V(:,1)==c(end)) & (V(:,2)==c(1) | V(:,2)==c(end))) & (V(:,3)==c(1) | V(:,3)==c(end)) );
W(Jvertices)=1/2*W(Jvertices); %weights on vertices

f(JU)=W.*f(JU);
integral=(pi^3)*sum(f); %this is the value of the intergral in the 
                                  %Chebyshev measure

return