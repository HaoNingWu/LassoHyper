function [Calfa,M,P,Calfa1]=CX_Calfa(F,n)
% --------------------------------------------------------------
% This function computes the coefficients C_alfa.
%
% inputs: F=3d array containing the values of the function f
%         n=degree along one direction
% outputs: Calfa=the coefficients
%          M=an array of indices
%          P=array of pointers to 3-indices of length <= n+2
%          Calfa1=the coefficients used for error estimates
%                 (these coefficients are the ones such that the 
%                  3-indices alfa satisfy, n+1<=alfa<=n+2)
% ---------------------------------------------------------------
% Authors: 
%      Stefano De Marchi
%      Department of Computer Science
%      University of Verona
%   
%      Marco Vianello
%      Department of Pure and Applied Math.
%      University of Padova
%      
% Version: May 2008
%-----------------------------------------------------------------
% FFT of the F values. The FFT is done taking the real part
% of FFT along all (three) directions.
%-----------------------------------------------------------------
C=real(fft(real(fft(real(fft(F,2*n,3)),2*n,2)),2*n,1));

% array of indices

[Mx,My,Mz]=ndgrid(1:n+1);
M=[Mx(:) My(:) Mz(:)];
C1=C(1:n+1,1:n+1,1:n+1);
CC1=reshape(C1,(n+1)^3,1);

% scaling the coefficients

PC1=find(M(:,1) ~= 1);
CC1(PC1)=sqrt(2)*CC1(PC1);
PC2=find(M(:,2) ~= 1);
CC1(PC2)=sqrt(2)*CC1(PC2);
PC3=find(M(:,3) ~= 1);
CC1(PC3)=sqrt(2)*CC1(PC3);

P=find(M(:,1)+M(:,2)+M(:,3) <= n+2 );  % array of pointers to 3-indices of length <= n+2

P1=find(M(:,1)+M(:,2)+M(:,3) >= n+1 &  M(:,1)+M(:,2)+M(:,3) <= n+2 );
Calfa=CC1(P);  % The coefficients
Calfa1=CC1(P1);
return
