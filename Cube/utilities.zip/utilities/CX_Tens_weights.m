function [F,W]= CX_Tens_weights(n,f,c,V)
% ------------------------------------------
%  M-function that allows to 
%  compute the cubature/interpolation weights
%
% inputs: n=degree; f=array of function values;
%         c=Chebyshev points in [-1,1]; 
%         V=points in the cube (3d array)
%
% outputs: F=3d structure, (n+1)x(n+1)x(n+1), 
%            containing the values fo f
%          W=the cubature/interpolation weights
% --------------------------------------------
%  Authors: 
%      Stefano De Marchi
%      Department of Computer Science
%      University of Verona
%   
%      Marco Vianello
%      Department of Pure and Applied Math.
%      University of Padova
%      
% Version: May 2008
% -----------------------------------------
W=1/n^3*ones(size(V,1),1);

Jfaces=find((V(:,1)==c(1) | V(:,1)==c(end))| (V(:,2)==c(1) | V(:,2)==c(end)) | (V(:,3)==c(1) | V(:,3)==c(end))  );
W(Jfaces)=1/2*W(Jfaces); %pesi sulle facce

Jedges=find(( (V(:,1)==c(1) | V(:,1)==c(end)) & (V(:,2)==c(1) | V(:,2)==c(end))) |  ...
  ((V(:,1)==c(1) | V(:,1)==c(end)) & (V(:,3)==c(1) | V(:,3)==c(end))) |  ...    
((V(:,2)==c(1) | V(:,2)==c(end)) & (V(:,3)==c(1) | V(:,3)==c(end)) ));
W(Jedges)=1/2*W(Jedges); %pesi sugli spigoli

Jvertices=find(( (V(:,1)==c(1) | V(:,1)==c(end)) & (V(:,2)==c(1) | V(:,2)==c(end))) & (V(:,3)==c(1) | V(:,3)==c(end)) );
W(Jvertices)=1/2*W(Jvertices); %pesi sui vertici

f=W.*f;
F=reshape(f,n+1,n+1,n+1);
return