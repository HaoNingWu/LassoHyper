function p = ViewTriMesh(FV,a,color,View)

% figure
p = patch(FV);
if exist('color')~=1
    color = [.99 .6863 0];
    set(p,'FaceColor',color);
else
    set(p,'FaceColor','interp');
    set(p,'FaceVertexCData',color);
    pp=colorbar;
    set(pp,'fontsize',18);
end
set(p,'edgecolor','none');
alpha(a)
daspect([1 1 1])
view(3)
axis tight
axis off
material dull
camlight
lighting phong

if exist('View')==1
    switch View
        case 'EricCartman'
            set(gca,'CameraPosition',[16.978097056173571  -3.146704293146104   1.207442943709381]);
        case 'Lena'
            set(gca,'CameraPosition',[1.046051506967765 -14.959233488476578  -8.657807465287977]);
        case 'Barbara'
            set(gca,'CameraPosition',[2.165974853404818  15.411711891362224   7.590665974474653]);
    end
end