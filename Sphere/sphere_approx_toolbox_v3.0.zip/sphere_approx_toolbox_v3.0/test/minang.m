function [amin, amax, imin, jmin] = minang(X, ipr)
% [amin, amax, imin, jmin] = minang(X, ipr)
% Calculate the smallest and largest angle (radians) between the points in X
% The minimum angle is twice the packing radius for sperical caps on unit sphere S^2
% The minimum angle is attained for points imin and jmin
% If ipr > 0, print a summary of results (default ipr = 0);

if nargin < 2
    ipr = 0;
end;

t0 = cputime;

% Scale factor: 1 radian = sc degrees
sc = 180 / pi;

% There are m points in X
[r, m] = size(X);

% Calculate larest and smallest inner prrducts of points
cmax = -Inf;
cmin = Inf;
z = [];
for i = 1:m-1
    
    J = [i+1:m];
    z = X(:,i)'*X(:,J);
    [cmax, jm] = max([cmax z]);

    if jm > 1
        imin = i;
        jmin = J(jm-1);
        %X(:,imin)'*X(:,jmin)
    end;
    
    cmin = min([cmin min(z)]);
    
end;
amin = acos(cmax);
amax = acos(cmin);

tc = cputime - t0;

if ipr > 0
    fprintf('Max cosine = %9.6f, min angle = %9.6f radians, %.6f degress\n', cmax, amin, amin*sc);
    fprintf('Minimum angle is attained for points %d and %d\n', imin, jmin);
    fprintf('Min cosine = %9.6f, max angle = %9.6f radians, %.6f degress\n', cmin, amax, amax*sc);
    fprintf('Calculation time = %.2f secs\n', tc);
end;

