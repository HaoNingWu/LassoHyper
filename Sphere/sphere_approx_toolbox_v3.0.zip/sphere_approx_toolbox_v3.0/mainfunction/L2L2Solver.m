function [ alpha, history ] = L2L2Solver( obj, YL, f, lambda, beta, varargin )
%L2L1SOLVER Summary of this function goes here
%   Detailed explanation goes here
% Solves the following problem directly or use pcg:
%
%   minimize || YL*alpha - f ||_2^2 + \lambda || RL'*alpha ||_2
%
%  input:	obj: objective function, (function handle)
%           YL:  spherical function matrix of pointset, ((L+1)^2*N)
%           f:   real value, (N*1)
%           t:   degree of pointset, (1*1)
%           beta: regularization operator of model, ((L+1)^2*1)
%           lambda: regularization parameter of model, (1*1)
%           rho: penalty parameter of lagrangian multiplier
%           relaxation:  relaxation parameter in z-update ([1, 1.8])
%  output:  alpha: solution, ((L+1)^2*1)
%           history: contains the objective value, the primal and dual 
%                    residual norms, and the tolerances for the primal and 
%                    dual residual norms at each iteration.(struct)


% get data in varargin
t = varargin{1};
L = varargin{2};

t_start = tic;
% Global constants and defaults
QUIET    = 1;
MAX_ITER = 1000;
ABSTOL_PCG   = 1e-30;

% Data preprocessing
% m = (L+1)^2
% n = N , number of point set
[m, n] = size(YL);

% save a matrix-vector multiply
% TL = YL*YL' + lambda*diag(beta)*(YL*YL')*diag(beta)';
YLf = YL*f;

% solver
alpha = zeros(m,1);

if t >= L && t < 2*L
    TL = YL*YL' + lambda*diag(beta)*(YL*YL')*diag(beta)';
    % solve a linear equation 
    % using preconditioned conjugate gradient (PCG) algorithm
    % using Cholesky factorization
    L = chol(TL, 'lower');
    [alpha, flag, relres, iter, resvec] = ...
        pcg(TL, YLf, ABSTOL_PCG, MAX_ITER, L, L');
    
    % restore history
    history.flag = flag;
    history.relres = relres;
    history.r_norm  = resvec;
    % alpha = HL\YLf;
elseif t >= 2*L
    % solve the problem directly
    % YL'*YL = I
    % invTL = (4*pi/n) * diag( 1./(1+lambda*(beta.^2)) );
    % alpha = invTL * YLf;
    HL = YL*YL';
    TL = HL + lambda*diag(beta)*(HL)*diag(beta)';
    alpha = TL \ YLf;
    history = [];
end

% restore res
[history.obj_val, history.item_1, history.item_2] ...
    = obj(YL, f, lambda, alpha, beta);

if ~QUIET
    toc(t_start);
end
end




