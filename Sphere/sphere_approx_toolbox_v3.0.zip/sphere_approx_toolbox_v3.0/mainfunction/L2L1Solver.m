function [ sol_alpha, history ] = L2L1Solver( obj_num, YL, f, lambda, beta, varargin )
%L2L1SOLVER Summary of this function goes here
%   Detailed explanation goes here
% Solves the following problem via ADMM:
%
%   minimize || YL*alpha - f ||_2^2 + \lambda || zeta ||_1
%   s.t.     RL'*alpha - zeta = 0
%
%  input:	obj: objective function, (function handle)
%           YL:  spherical function matrix of pointset, ((L+1)^2*N)
%           f:   real value, (N*1)
%           t:   degree of pointset, (1*1)
%           beta: regularization operator of model, ((L+1)^2*1)
%           lambda: regularization parameter of model, (1*1)
%           rho: penalty parameter of lagrangian multiplier
%           relaxation:  relaxation parameter in z-update ([1, 1.8])
%  output:  alpha: solution, ((L+1)^2*1)
%           history: contains the objective value, the primal and dual
%                    residual norms, and the tolerances for the primal and
%                    dual residual norms at each iteration.(struct)

% t_start = tic;
% Global constants and defaults

% if 1 || isempty(obj_num)
%     obj = @obj_L2L1;
% end
rho = varargin{1};
t = varargin{2};
L = varargin{3};
% func_name = varargin{4};

QUIET    = 0;
MAX_ITER = 1000;

ABSTOL   = 1e-4;
RELTOL   = 1e-4;

rho_nu = [10^3, 10^-2];
rho_inc_ratio = 1.5;
rho_dec_ratio = 1.35;
rho_alter_ratio = [rho_inc_ratio; rho_dec_ratio];

[m, n] = size(YL);

HL = YL*YL';
if t >= 2*(sqrt(m)-1)
    TL = (4*pi/n) * diag( 1./(2+rho*(beta.^2)) );
else
    TL = 2*(HL) + rho*diag(beta)*(HL)*diag(beta)';
end
YLf = YL*f;
RL = diag(beta)*YL;
alpha = zeros(m,1);
zeta = zeros(n,1);
u_k = RL'*alpha - zeta;
admm_time = 1;
coder.extrinsic('now');
coder.extrinsic('datenum');
while 1
    [ sol_alpha, status, history ] = iter( YL, f, beta, HL, TL, YLf, RL, alpha, zeta, u_k, lambda, rho, rho_nu, rho_alter_ratio, QUIET, MAX_ITER, ABSTOL, RELTOL );

    k = length(history.obj_val);
    
    if status == 1 
        break;
    elseif (status == 2 && admm_time > 0) ...
            || (status == 3 && admm_time > 0)
        break;
    else
        ABSTOL   = 1e-3;
        RELTOL   = 1e-3;
    end
    admm_time = admm_time + 1;
end

end

function z = shrinkage(x, kappa)
z = max( 0, x - kappa ) - max( 0, -x - kappa );
end

function [obj_val, item_1, item_2] = obj_L2L1(YL, f, lambda, beta, alpha, varargin)
%OBJ_LASSO Summary of this function goes here
%   Detailed explanation goes here

% value of each item
item_1 = sum((YL'*alpha - f).^2);
item_2 = norm(YL'*diag(beta)*alpha, 1);

% objective function value
obj_val = item_1 + lambda*item_2;

end

% function [ sol_alpha, status, history ] = iter( varargin )
% [ YL, f, beta, HL, TL, YLf, RL, alpha, zeta, u_k, lambda, rho, rho_nu, rho_alter_ratio, QUIET, MAX_ITER, ABSTOL, RELTOL ]...
%     = deal(varargin{:});
% % clear varargin
% [m, n] = size(YL);
% t = sqrt(n)-1;
% obj_val  = zeros(MAX_ITER, 1);
% rho_val = zeros(MAX_ITER, 1);
% r_norm  = zeros(MAX_ITER, 1);
% s_norm  = zeros(MAX_ITER, 1);
% eps_pri = zeros(MAX_ITER, 1);
% eps_dual= zeros(MAX_ITER, 1);
% 
% k = 1;
% status = 0;
% 
% while 1
%     if t >= 2*(sqrt(m)-1)
%         alpha = TL * ( 2*YLf + rho*RL*(zeta-u_k) );
%     end
%     zetaold = zeta;
%     nu = RL*alpha + u_k;
%     zeta = shrinkage(nu, lambda/rho);
%     u_k = u_k + (RL*alpha - zeta);
%     [obj_val(k)]  = obj_L2L1(YL, f, lambda, beta, alpha);
%     rho_val(k)  = rho;
%     r_norm(k)  = norm(RL*alpha - zeta);
%     s_norm(k)  = norm(-(min(rho))*(zeta - zetaold)); 
%     eps_pri(k) = sqrt(n)*RELTOL + ABSTOL*max(norm(-alpha), norm(u));
%     eps_dual(k)= sqrt(n)*RELTOL + ABSTOL*norm(u);
% 
%     if (r_norm(k) < eps_pri(k) && s_norm(k) < eps_dual(k))
%         status = 1;
%         break;
%     end
%     k = k + 1;
% end
% 
% history.obj_val = obj_val(1:k);
% end

