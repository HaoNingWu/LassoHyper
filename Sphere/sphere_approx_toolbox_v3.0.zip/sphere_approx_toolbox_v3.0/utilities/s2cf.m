function X = s2cf(S);
% X = s2cf(S);
% Convert the spherical representation S of a system of m points
% on the unit sphere S^2 in R^3 into cartesian coordinates X
% S is a 2 by d matrix containing the angles theta and phi
% The polar angle theta in [0, pi] is the first row of S
% The azimuthal angle phi in [0, 2*pi) is the second row of A
% X is a 3 by m matrix containing the m cartesian points on the sphere

% Number of points on the sphere
m = size(S, 2);

% Polar angle theta and azimuthal angle phi
theta = S(1,:);
phi = S(2,:);

X = zeros(3,m);
st = sin(theta);
X(1,:) = st .* cos(phi);
X(2,:) = st .* sin(phi);
X(3,:) = cos(theta);
