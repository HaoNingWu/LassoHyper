% �������(Q_*)_{i,l^2+k}:=Y_{l,k}(x_i^*)  
% ��
function Y = getQ(X, L)
X_temp = X(:,1:3);
S = c2sf(X_temp'); %get the spherical coordinate;
z = cos(S(1,:));
Y = zeros( size(X,1), (L+1)^2 );
% Y(:,1) = ( spharmrds (0 , z , S(2,:)) )';
for LL=0:L
    Y(:, ((LL^2+1):((LL+1)^2)) ) = (spharmrds( LL, z, S(2,:) ))';
    %Y = [Y , (spharmrds( l, z, S(2,:) ))' ];
end
end
