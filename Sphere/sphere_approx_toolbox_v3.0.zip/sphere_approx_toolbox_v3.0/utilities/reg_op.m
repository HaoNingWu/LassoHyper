function [ beta ] = reg_op( type, max_L, parameter )
%REGOP Summary of this function goes here
%   Detailed explanation goes here

% regularization operator
%   type 1 : 0 operator
%   type 2 : filter operator
%   type 3 : laplace-beltrami regularization
%   type 4 : Identity Operator

switch type
    case 1
        % O ����((max_L+1)^2, 1);
        % B = zeros
        % BȫΪ0, ��������ʧЧ
        beta = zeros((max_L+1)^2);
    case 2
        % filter ����
        % B = diag( [ 0 {[1*(1+1)]^2}_{1..2*1+1} {[2*(2+1)]^2}_{1..2*2+1} ]  )
        beta = zeros( (max_L+1)^2, 1 );
        type_filter = parameter.type_filter;
        for idx = 0:max_L
            range = (idx^2+1):((idx+1)^2);
            beta( range ) = sqrt( 1/filter( type_filter, idx/(max_L+1) ) - 1) * ones(2*idx+1, 1);
        end
        % BL = (beta);
    case 3
        % Laplace-Beltrami����
        s = parameter.s;
        beta = zeros((max_L+1)^2, 1);
        for idx = 0:max_L
            range = (idx^2+1):((idx+1)^2);
            beta( range ) = ((idx*(idx+1)).^s) * ones(2*idx+1, 1);
        end
        % B = diag(beta);
    case 4
        % Identity Operator
        beta = ones((max_L+1)^2, 1);
end

end % reg_op( max_L, parameter )

function [ bl ] = filter( type, L_ratio )
% filter function
%   type 1 :
%   type 2 :
%   type 3 :
%   type 4 :
%   type 5 :

switch type
    case 1
        bl = (0<=L_ratio & L_ratio<0.5) * 1 ...
            + (0.5<=L_ratio & L_ratio<1.5) * ( -8*L_ratio.^2+8*L_ratio-1 ) ...
            + (1.5<=L_ratio & L_ratio<2) * ( 8*L_ratio.^2-16*L_ratio+8 ) ...
            + (1<=L_ratio) * 0;
    case 2
        bl = (0<=L_ratio & L_ratio<=0.5) * 1 ...
            + (0.5<L_ratio & L_ratio<1) * ( (sin(pi*L_ratio))^2 ) ...
            + (1<=L_ratio) * 0;
    case 3
        bl = (0<=L_ratio & L_ratio<=0.5) * 1 ...
            + (0.5<L_ratio & L_ratio<1) * ( 1-3*(2*L_ratio-1).^2+2*(2*L_ratio-1).^3 ) ...
            + (1<=L_ratio) * 0;
    case 4
%         bl = (0<=L_ratio & L_ratio<0.5) * 1 ...
%             + (0.5<=L_ratio & L_ratio<1) * ( exp( (-2*exp(-2/(1-L_ratio)))./(2-L_ratio) ) ) ...
%             + (1<=L_ratio) * 0;
        bl = (0<=L_ratio & L_ratio<=0.5) * 1 ...
            + (0.5<L_ratio & L_ratio<1) * ( exp( (exp(-2./(2*L_ratio-1)))./(L_ratio-1) ) ) ...
            + (1<=L_ratio) * 0;
    case 5
        if (0<=L_ratio && L_ratio<=0.5)
            bl = 1;
        elseif (0.5<L_ratio && L_ratio<1)
            bl = max( eps, 1 - exp( (2*exp(1./(L_ratio-1)))./(1-2*L_ratio) ) );
        elseif (1<=L_ratio)
            bl = 0;
        end   
end

end % filter( L_ratio, type )
