function [f, ft] = Franke_cap( X, delta, varargin )
% f = Franke(X) + 1e-1*rand(size(Franke_s(X)));
f = Franke(X);
% f = f + delta*1e-1*rand( size(f) );
if delta > 0
    f = f + normrnd( 0, delta, size(f) );
%     f = f + delta*1e-1*rand(size(f));
end
end

function f = Franke(s)
% Franke����
%  if min(size(s))~=1&&size(s,2)<=size(s,1);
if size(s,2)~=3;
    s=s';
end
x=s(:,1);y=s(:,2);z=s(:,3);
f_1 = 0.75*exp(-((9*x-2).^2)/4-((9*y-2).^2)/4-((9*z-2).^2)/4) ...
    +0.75*exp(-((9*x+1).^2)/49-((9*y+1))/10-((9*z+1))/10)...
    +0.5*exp(-((9*x-7).^2)/4-((9*y-3).^2)/4-((9*z-5).^2)/4)...
    -0.2*exp(-((9*x-4).^2)-((9*y-7).^2)-((9*z-5).^2));

f_cap = zeros(size(f_1));
dist = acos( s*[-1/2, -1/2, 1/sqrt(2)]' );
r = 1/2;
rho = 2;
f_cap(dist< r) = rho*cos( pi*dist(dist<=r)/(2*r) );
% f_cap(dist>=r) = 0;

f = f_1 + f_cap;
end