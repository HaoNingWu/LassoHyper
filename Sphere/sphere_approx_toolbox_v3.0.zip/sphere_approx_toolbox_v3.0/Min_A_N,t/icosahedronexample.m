
f=1; 
r=1;
sphere = 1;
make_plot=1;
faceopaque=1;

[ x, y, z, TRI]=make_icosahedron(f, r, sphere, make_plot, faceopaque); 
% x, y, z,save x,y,z
clear all
%%%%%%%%%%%%%%%%%%%%%incribed of a sphere
hold on,sphere
alpha(0.2)
shading('interp')

f=4; 
r=1;
sphere =1;
make_plot=1;
faceopaque=0;

[ x, y, z, TRI]=make_icosahedron(f, r, sphere, make_plot, faceopaque);
alpha(0.2)
shading interp