% L=19;
% N=200
F=[];NN=[];MY=[];MY1=[];
H=[];Angle=[];
XS=[];
RS=[];
for L=1:24
    N=(L+1)^2
%  for N=200:441
%  N=441
% z = 2*rand(1,N-1) - 1;
%     s0 = acos(z);
%     s0 = [s0 (2*pi)*rand(1,N-2)];
%     %s0 = ss;
%     X0 = s2cn(s0);
%     s0 = c2sn(X0);
%     fprintf('Pseudo-random intial points\n');
% %

 X0 = ptsspb(N, 8, 9, 1.8);
[f,N,XX,minY,minY1,ht,at,rs] = Amin(X0,L);
%   KMatrix1(end+1,:) = KArray1 ;
%             KMatrix2(end+1,:) = KArray2 ;
F(end+1,:)=f;
NN(end+1,:)=N;
XS=[XS,XX];
MY(end+1,:)=minY;
MY1(end+1,:)=minY1;
H(end+1,:)=ht;
Angle(end+1,:)=at;
RS(end+1,:)=rs;
 end
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 x=1:24
% %   x=200:201;
figure(11),plot(x,F,'*'),grid on,xlabel(' Degree t');title('The behavior of final A_{N,19} ','fontSize',12)
  figure(12),plot(x,MY,'*'),grid on,xlabel('Degree t');title('The behavior of minimal singular vaule of Y_{t}','fontSize',12)
   figure(13),plot(x,MY1,'*'),grid on,xlabel('Degree t');title('The behavior of minimal singular vaule of Y_{t+1}','fontSize',12)
    figure(14),plot(x,H,'*'),grid on,xlabel('Degree t');title('The behavior of mesh norm ','fontSize',12)
     figure(15),plot(x,Angle,'*'),grid on,xlabel('Degree t');title('The behavior of minimal angle ','fontSize',12)
      figure(16),plot(x,RS,'*'),grid on,xlabel('Degree t');title('The behavior of 2-norm of residual  ','fontSize',12)
%  

