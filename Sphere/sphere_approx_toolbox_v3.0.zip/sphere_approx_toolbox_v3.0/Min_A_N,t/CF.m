function CF=CF(x)
%x is a m by 3 matrix
CF=0
[m,t]=size(x);
for i=1:m
 for   j=1:m
     
    CF=CF+(1./(norm(x(i,:)-x(j,:))));
 end 
end
