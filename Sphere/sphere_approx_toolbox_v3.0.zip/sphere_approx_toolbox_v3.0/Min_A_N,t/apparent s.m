spherepoint(XX)
shading flat
figure(1)
show
alpha(0.4)
axis vis3d
h = light;
for az = -50:10:50
    lightangle(h,az,30)
    drawnow
end