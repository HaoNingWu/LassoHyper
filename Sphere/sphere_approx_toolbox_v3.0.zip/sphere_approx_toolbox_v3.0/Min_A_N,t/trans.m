function [a,b]=trans(x,y)

a = sqrt(x^2+y^2);

if x>0
   b = arsin(y/a);
   if b<0
      b = 360-d;
   end
else
   b = 180-arcsin(y/a);
end 