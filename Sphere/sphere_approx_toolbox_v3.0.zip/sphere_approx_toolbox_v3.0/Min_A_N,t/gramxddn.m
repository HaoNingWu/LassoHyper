function [G, DG, DDG] = gramxddn(X, n, ipr)
% [G, DG] = gramxd(X,n, ipr)
% Calculate the Gram matrix G and its deriviative DG w.r.t. Z = X'*X
% for the fundamental system X on the Sphere S(2) in R^3
% X is an 3 by m matrix contaning the fundamental system
% G is a m by m symmetric positive semidefinite matrix
% G is nonsingular and hence positive definite if X is a fundametnal system
% DG is a m by m symmetric matirx of derivatives of G w.r.t Z = X'*X
% Derivative of G w.r.t. X(i,j) is  ej*ej'*DG*Di + Di*DG*ej*ej'
% where Di = diag(X(i,:)) and ej is j th unit vector in R^m.
%C_W work
if nargin < 3
    ipr = 0;
end;

CalcDeriv = nargout - 1;

t0 = cputime;

% For the sphere in R^3 the number of interpolation points m = (n+1)^2, where
% n is the degree of the interpolating polynomials on the sphere
m = size(X,2);
if nargin < 2
    n = sqrt(m) - 1;
end;

% Area of unit sphere S^2 in R^3
S2area = 4*pi;

% Evaluate using symmetry of G, DG and Gegenbauer polynomials
% Should initliaze diagonal elements of G and DG
% and then only use z = X(:,i)'*X(:,i+1:m) to get G(i,i+1:m) etc
% Explicity using the symmetry roughly halves the number of flops
% to caclulate G, but introduces a slow for loop
% This is faster for n >= 20 or so
Gdiag = (n+1)^2 / S2area;            % (n+1)^2 / S2area
DGdiag = n*(n+2)*Gdiag / 4;          %  n * (n+1)^2 * (n+2) / (4*S2area); 
DDGdiag = (n-1)*(n+3)*DGdiag / 6;    % (n-1) * n * (n+1)^2 * (n+2) * (n+3) / (24*S2area);
G = diag(Gdiag * ones(m,1));
if CalcDeriv > 0
    DG = diag(DGdiag * ones(m,1));
    if CalcDeriv > 1
        DDG = diag(DDGdiag * ones(m,1));
    end;
end;

% Loop over strict upper traingle as diagonal specified
% Strict lower triangle given by symmetry
for i = 1:m-1
    
    I = [i+1:m];
    xi = X(:,i);
    XI = X(:,I);
    z = xi'*XI;
    
    % Make sure elements of A are in [-1, 1]
    z = max(z, -1);
    z = min(z, 1);
    
    if CalcDeriv == 2
        [p, Dp, DDp] = gegen(n, z);
        G(i,I) = p;
        G(I,i) = p';
        DG(i,I) = Dp;
        DG(I,i) = Dp';
        DDG(i,I) = DDp;
        DDG(I,i) = DDp';
    elseif CalcDeriv == 1
        [p, Dp] = gegen(n, z);
        G(i,I) = p;
        G(I,i) = p';
        DG(i,I) = Dp;
        DG(I,i) = Dp';
    else
        p = gegen(n, z);
        G(i,I) = p;
        G(I,i) = p';
    end;
    
end;

tc = cputime  - t0;

if ipr > 0
    fprintf('Calculating degree %d Gram matrix and %d derivatives for N = %d points', n, CalcDeriv, m);
    fprintf(': Time = %.2f secs\n', tc);
end;
