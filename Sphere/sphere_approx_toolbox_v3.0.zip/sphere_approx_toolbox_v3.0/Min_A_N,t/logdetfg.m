function [f, Df, H] = logdetfg(s,L)
% [f, Df] = logdetfg(s)
% Calculate the negative of the log of the determinant of G
% f = -log(det(G)) = -2*sum(log(diag(R)))
% where R is the Cholesky factor of G
% DF is the derivative of f w.r.t. the spherical parametrization s
% of a fundamental system X of d points on the unit sphere S^2
% s is a 2*d-3 vector of theta(2:d), phi(3:d) with first
% points fixed at the north pole (theta(1) = 0, phi(1) anything),
% second point on the prime meridian (phi(2) = 0)
% Minimizing f will maximize the determinant of G
% 
% Uses the Choleski factorization of G and the result that the
% derivative of log det G = trace( inv(G) * dervative of G )

global Fcount Gcount

% Determine if gradient and Hessian should be calculated
calcg = nargout > 1;
calcH = nargout > 2;

% If rank 2 array is input, assume it is cartesian representation X
if min(size(s)) > 1
    X = s;
    s = c2sn(X)';
else
   % Ensure input is a row vector
   s = s(:)';
   % Convert spherical coordiantes into cartesion representation
   X = s2cn(s);
end;

% Number of points on sphere
d = size(X,2)

% Tolerance for singular Gram matrix
tol = (d^2/(4*pi))*eps;

% Calculate Gram matrix G from fundamental system X
% and if required the derivative of G w.r.t Z = X'*X
% Update function counter
L=9
Fcount = Fcount + 1;
if calcg
   % Update gradient counter
   Gcount = Gcount + 1;
%    [G, DG] = gramxd(X);

   [G, DG] =gramxddL(X,L);
else
%    G = gramxd(X);
    G =gramxddL(X,L);
end;

% Choleski factorization
[R, p] = chol(G);
if p ~= 0
   G = G + tol*speye(size(G));
   R = chol(G);
end;

% Determinant of G is det(R)^2 and
% det(R) = prod diagonal elements of RA as R is traingular
f = -2*sum(log(diag(R)));

% Calculate gradient w.r.t spherical parametrization in S
if calcg
   
    theta = [0, s(1:d-1)]';
% theta = [0, s(1:d-1)];
   phi = [0, 0, s(d:end)]';
%  phi = [0, s(d:end)];
   ct = cos(theta);
   st = sin(theta);
   cp = cos(phi);
   sp = sin(phi);

   % LDG = inv(G)*DG = G \ DG = R'\(R\DG)
   W = 2 * X * (inv(G) .* DG);
   w1 = W(1,:)';
   w2 = W(2,:)';
   w3 = W(3,:)';
   
   % Derivatives w.r.t spherical parametrization
   Dtheta = w1.*(ct.*cp) + w2.*(ct.*sp) - w3.*st;
   Dphi = -w1.*(st.*sp) + w2.*(st.*cp);

   % Derivative of -log(ev(i)) w.r.t. variables S
   Df = -[Dtheta(2:d); Dphi(3:d)];
   
end;

if calcH
    
    H = fdhess('logdetfg', s, Df);
    
end;
