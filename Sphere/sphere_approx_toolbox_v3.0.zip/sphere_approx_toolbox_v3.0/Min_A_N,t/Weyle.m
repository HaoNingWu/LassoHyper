figure(11),plot(eigG5,'*')

hold on,plot(eigG4,'o')
hold on,plot(eigG4+max(eig(G5-G4)),'^')
title('Weyl Theory estimate for eignvalue of G_{t+5} ','fontSize',12)
xlabel('Number','fontSize',19)
ylabel('Eignvalue for gram matrix','fontSize',19)
h = legend('eignvalue of G_{t+5}','eignvalue low bound estimate of G_{t+5}','eignvalue upper bound estimate  of G_{t+5}',3);%

%--------------------------------------------
figure(12),plot(eigG4,'*')

hold on,plot(eigG3,'o')
hold on,plot(eigG4+max(eig(G4-G3)),'^')
title('Weyl Theory estimate for eignvalue of G_{t+4} ','fontSize',12)
xlabel('Number','fontSize',19)
ylabel('Eignvalue for gram matrix','fontSize',19)
h = legend('eignvalue of G_{t+4}','eignvalue low bound estimate  of G_{t+4}','eignvalue upper bound estimate  of G_{t+4}',3);%

%------------------------------------------------
figure(13),plot(eigG3,'*')

hold on,plot(eigG2,'o')
hold on,plot(eigG4+max(eig(G3-G2)),'^')
title('Weyl Theory estimate for eignvalue of G_{t+3}','fontSize',12)
xlabel('Number','fontSize',19)
ylabel('Eignvalue for gram matrix','fontSize',19)
h = legend('eignvalue of G_{t+3}','eignvalue of low bound estimate G_{t+3}','eignvalue upper bound estimate of G_{t+3}',3);%
%----------------------------------------------
figure(14),plot(eigG2,'*')

hold on,plot(eigG1,'o')
hold on,plot(eigG4+max(eig(G2-G1)),'^')
title('Weyl Theory estimate for eignvalue of G_{t+2}','fontSize',12)
xlabel('Number','fontSize',19)
ylabel('Eignvalue for gram matrix','fontSize',19)
h = legend('eignvalue of G_{t+2}','eignvalue low bound estimate of G_{t+2}','eignvalue estimate upper bound of G_{t+2}',3);%
