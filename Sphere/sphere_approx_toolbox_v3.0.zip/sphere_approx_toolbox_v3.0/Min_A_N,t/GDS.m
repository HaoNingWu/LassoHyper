function GD=GDS(XX)
%x is a matrix
[d,t]=size(XX);
% d=d(2);
% d=36;
b=0;
for i=1:d;
    for j=1:d

a=dot(XX(i,:),XX(j,:));
b=b+(1-2*log(1+real(sqrt((1-a)/2))));

    end
end
GD=real(sqrt(b));
GD=(1/(2*sqrt(pi)*d))*GD;

%  plot(G(1:32,2), 'DisplayName', 'G(1:32,2)', 'YDataSource', 'G(1:32,2)'); figure(gcf)
% hold on
% plot(G(1:32,1),'*', 'DisplayName', 'G(1:32,1)', 'YDataSource', 'G(1:32,1)'); figure(gcf)
% hold on,plot(G(1:32,3),'^', 'DisplayName', 'G(1:32,1)', 'YDataSource', 'G(1:32,1)'); figure(gcf)
%  set(gca, 'YScale', 'log')
% grid on
% title('Generalized discrepancy for different N')
% xlabel('degree')