function [R,Theta,Phi]=car2pol(X,Y,Z);
R=sqrt(X.*X+Y.*Y+Z.*Z);
Theta=atan2(Y,X);
if Theta<0
    Theta=Theta+2*pi;
end
Phi=atan(sqrt(X.*X+Y.*Y)./Z);

