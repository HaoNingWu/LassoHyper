% Regular tetrahedron on unit sphere S^2

% Normalized (first point north pole, second point on prime meridian)

% 4 points, 4 equilateral triangular faces

% One of the Platonic solids whih is universally optimal

% 4 triangular Voronoi cells each with area pi

% ALL inner products between pairs of different points = -1/3

% Gram matrix for degree 1 is G = (1/pi) I

% Maximum determinant = (1/pi)^4, all eigenvaleus = 1/pi

% Covering radius = acos(1/3) = 1.2309....

% Separation = acos(-1/3), Packing radius = acos(-1/3)/2 = 0.9553....

% Coulomb energy = 3*sqrt(3/2) using sum over j > i

% Spherical 2-design, weights w_i = pi for i = 1:4



X = [ 0 sqrt(8)/3  -sqrt(2)/3  -sqrt(2)/3;

      0    0        sqrt(2/3)  -sqrt(2/3);

      1  -1/3      -1/3        -1/3]

  