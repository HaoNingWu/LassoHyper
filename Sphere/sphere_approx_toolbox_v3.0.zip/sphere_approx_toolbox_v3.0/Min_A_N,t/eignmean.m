% a=[0.3183
% 0.7162
% 1.2732
% 1.9894
% 2.8648
% 3.8993
% 5.0930
% 6.4458
% 7.9577
% 9.6289
% 11.4592
% 13.4486
% 15.5972
% 17.9049
% 20.3718
% 22.9979
% 25.7831
% 28.7275
% 31.8310
% 35.0937];
% 

a1=[0.7162
1.2732
1.9894
2.8648
3.8993
5.0930
6.4458
7.9577
9.6289
11.4592
13.4486
15.5972
17.9049
20.3718
22.9979
25.7831
28.7275
31.8310
35.0937
38.5155
];
a2=[1.2732
1.9894
2.8648
3.8993
5.0930
6.4458
7.9577
9.6289
11.4592
13.4486
15.5972
17.9049
20.3718
22.9979
25.7831
28.7275
31.8310
35.0937
38.5155
42.0965
];
a3=[1.9894
2.8648
3.8993
5.0930
6.04458
7.9577
9.6289
11.4592
13.4486
15.5972
17.9049
20.3718
22.9979
25.7831
28.7275
31.8310
35.0937
38.5155
42.0965
45.8366
];
a4=[2.8648
3.8993
5.0930
6.4458
7.9577
9.6289
11.4592
13.4486
15.5972
17.9049
20.3718
22.9979
25.7831
28.7275
31.8310
35.0937
38.5155
42.0965
45.8366
49.7359
];
a5=[3.8993
5.0930
6.4458
7.9577
9.6289
11.4592
13.4486
15.5972
17.9049
20.3718
22.9979
25.7831
28.7275
31.8310
35.0937
38.5155
42.0965
45.8366
49.7359
53.7944
];
%-----------------
% hold on,plot(a,'-o')
hold on ,plot(a1,'*','MarkerSize',4.7)
hold on ,plot(a2,'.','MarkerSize',4.7)
hold on ,plot(a3,'^','MarkerSize',4.7)
hold on ,plot(a4,'rs','MarkerSize',3.7)
hold on ,plot(a5,'hk','MarkerSize',4.7)
%----------------------------------
title('Average eignvalue for  Gram matrice of spherical t-design N=(t+4).^2 ')

% title('Average eignvalue for  Gram matrice of spherical t=4 design N=(t+4).^2 ')
xlabel('t')
ylabel('Average eignvalue for gram matrix')
legend('Average eignvalue of G_{t+1}','Average eignvalue of G_{t+2}','Average eignvalue of G_{t+3}','Average eignvalue of G_{t+4}','Average eignvalue of G_{t+5}',6);
%-----------------------------------------------------
% hold on,plot(eigG,'+')
%plot eignvalue
figure(2) ,plot(eigG1,'o','Linewidth',0.4,'MarkerSize',1.8)
hold on ,plot(eigG2,'x')
hold on ,plot(eigG3,'d','Linewidth',3,'MarkerSize',1.7)
hold on ,plot(eigG4,'r+','Linewidth',5,'MarkerSize',1.6)
hold on ,plot(eigG5,'sk','Linewidth',3,'MarkerSize',1.5)
title('Eignvalue for  Gram matrix G_{L} of spherical L=4  design N=(L+4).^2 ','fontSize',12)
xlabel('Number','fontSize',19)
ylabel('Eignvalue for gram matrix','fontSize',19)
h = legend('eignvalue of GL+1','eignvalue of GL+2','eignvalue of GL+3','eignvalue of GL+4','eignvalue of GL+5',5);%
%--------------------------------------------------------------------------
%-----------------
tL=[38.5155;86.6599;154.062;240.7219;346.6395;471.8148;616.2479;779.9388;962.8874;1165.1;1386.6;1627.3;1887.3;2166.5;2465;2782.7;3119.8;3476;3851.5;];
tL1=[86.6599;154.062;240.7219;346.6395;471.8148;616.2479;779.9388;962.8874;1165.1;1386.6;1627.3;1887.3;2166.5;2465;2782.7;3119.8;3476;3851.5;4246.3;];
tL2=[154.062;240.7219;346.6395;471.8148;616.2479;779.9388;962.8874;1165.1;1386.6;1627.3;1887.3;2166.5;2465;2782.7;3119.8;3476;3851.5;4246.3;4660.4;];
tL3=[240.7219;346.6395;471.8148;616.2479;779.9388;962.8874;1165.1;1386.6;1627.3;1887.3;2166.5;2465;2782.7;3119.8;3476;3851.5;4246.3;4660.4;5093.7;];

hold on ,plot(t1,'o')
hold on ,plot(t2,'.')
hold on ,plot(t3,'^')
hold on ,plot(t4,'rs')
title('Trace of Gram matrix for N=121,Different L=1,...20 ')
xlabel('L')
ylabel('Trace value')
h = legend('Trace of G_{L}','Trace of G_{L+1}','Trace of G_{L+2}','Trace of G_{L+3}',4);%
%%%

