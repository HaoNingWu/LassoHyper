% Spherical L-design with N points
% Either minimize the Sloan & Womersley function A_{L,N}
% or the sum of squares of the residual r = Y*e
% These are related by A_{L,N} = (|S^d| / N^2) r'*r
% From good starting points, minimizing sum of squares is more efficient
% Rob Womersely, School of Mathematics and Statistics, UNSW
clear all
format compact

% Specify degree L
L =3;
% Specify number of points N
N = (L+1)^2;

% Specify objective to be minimized,i.e choose you want min
% Minimize sum of squares of residual r = Y*e
%objective = 'sfresid';
% Minimize spherical design objective of Sloan & Womersley
objective = 'sdobj';

% Starting point set to load
pstr = 'me';
pdir = '../../Points/';

% Pseudo-random perturbation of initial spehrical points
% No perturbation of initial point set
%pert = 0;
% Based on the minimum angle ~ Pi/(L+1) for spherical design N ~ L^2/2
%pert = 0.5*pi/(L+1);
% Pseudo-random inital point set
pert = -1;
% Restart from previous iterate
%pert = -2;

tolx = 1e-14;
tolf = 1e-12;

% Define strings for loading initial point sets
Lstr = sprintf('%.3f', L/1e3); Lstr = Lstr(3:end);
Nstr = sprintf('%.5f', N/1e5); Nstr = Nstr(3:end);
%Lstr = sprintf('%.2f', L/1e2); Lstr = Lstr(3:end);
%Nstr = sprintf('%.4f', N/1e4); Nstr = Nstr(3:end);

if pert >= 0
    Pstr = [upper(pstr) '/' pstr];%
    ldstr = ['load ' pdir Pstr Lstr '.' Nstr];%
    fprintf('Starting points: %s\n', ldstr);%
    eval(ldstr);%
    X0str = ['X0 = ' pstr Lstr '(:,1:3)'';'];%
    eval(X0str)%
% load('XX.mat')
    s0 = c2sn(X0);
end;

if pert > 0
    % Pseudo randm perturbations
    srnd = 2*rand(size(s0))-1;
    % First N-1 elments are angles theta in [0, pi]
    % Elements N to 2*N-3 are angles phi in [0, 2*pi)
    s0 = s0 + pert*[srnd(1:N-1) 2*srnd(N:end)];
    X0 = s2cn(s0);
    s0 = c2sn(X0);
    fprintf('Perturbing intial points: pert = %3e\n', pert);
elseif pert == 0
    % Loaded initial point set
    X0 = s2cn(s0);
    fprintf('No perturbation of intial points\n');
elseif pert == -1
    % Pseudo-random points
    z = 2*rand(1,N-1) - 1;
    s0 = acos(z);
    s0 = [s0 (2*pi)*rand(1,N-2)];
    %s0 = ss;
    X0 = s2cn(s0);
    s0 = c2sn(X0);
    fprintf('Pseudo-random intial points\n');
elseif pert == -2
    % Restart from lst point from optimization
    % after mapping back to standard domain
    s0 = ss;
    X0 = s2cn(s0);
    s0 = c2sn(X0);
    fprintf('Restart intial points\n');
end;

fprintf('\n ---- Initial point set -----\n');
f0 = sdobj(s0, L, 1);
r0 = sfresid(s0, L, 1);
h0 = meshn(X0, 1);
a0 = minang(X0, 1);


opt = optimset('Display', 'Iter', 'TolX', tolx, 'TolFun', tolf);

% Select optimization method
if strcmp(objective, 'sfresid')
    % Minimize sum of squares of residual
    opt = optimset(opt, 'Jacobian', 'on');
    lb = []; ub = [];
    [ss, rssq, rr, flag] = lsqnonlin('sfresid', s0, lb, ub, opt, L);
    fprintf('LSQNONLIN: flag = %d\n', flag);
    [rs, A] = sfresid(ss, L, 3);
    XX = s2cn(ss);
elseif strcmp(objective, 'sdobj')
    % Minimize objective A_{L,N}
    % Quasi-Newton method has potenital problems from
    % periodicity of spherical parametrization of sphere
    opt = optimset(opt, 'GradObj', 'on', 'LargeScale', 'off');
    %opt = optimset(opt, 'InitialHessType', 'scaled-identity');
    [ss, fs, flag] = fminunc('sdobj', s0, opt, L);
    fprintf('FMINUNC: flag = %d\n', flag);
    [f, g] = sdobj(ss, L, 3);
    XX = s2cn(ss);
end;