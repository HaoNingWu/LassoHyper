extremal
t=19
[f,N,X,minY,minY1,ht,at,rs] = Amin(e19,t)



NRM = [1]
G = gramxddn(X, t);
Ginv = inv(G);
lagnrm =  findmax1a(X, t, Ginv, 0.9,  NRM, 1);
