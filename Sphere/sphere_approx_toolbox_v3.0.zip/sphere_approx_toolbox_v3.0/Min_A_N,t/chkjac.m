% Check Jacobian of residual functions

format compact

% Assumes base point sbase in spherical parametrization defined
s0 = sbase;
nv = length(s0);
X0 = s2cn(s0);
N = size(X0,2);

% Degree
L = 39;

% Objective name
fname = 'sfresid';
m = (length(s0)+3)/2;

[r0, A0] = feval(fname, s0, L, 1);

% Central difference step
h = eps^(1/3);;
fdtol = sqrt(eps)*nv;

fprintf('Checking Jacobian of %s, number of variables = %d\n', fname, nv);
fprintf('Spherical design: L = %d, N = 2m, N = %d, m = %d\n', L, N, m);
fprintf('Central difference stepsize = %.2e, tolerance = %.2e\n', h, fdtol);

% Check variables in index set J a subset of [1:nv]
J = [1:nv];
FD = zeros(size(A0));
E = zeros(size(1,nv));
for j = J
    
    sp = s0; sp(j) = sp(j) + h;
    rp = feval(fname, sp, L);
    sm = s0; sm(j) = sm(j) - h;
    rm = feval(fname, sm, L);
    FD(:,j) = (rp - rm) / (2*h);
    err = A0(:,j) - FD(:,j);;
    E(j) = norm(err, inf);
    fprintf('Variable j = %4d, FDE = %.4e\n', j, E(j));
    
end;

[Emax, jmax] = max(E);
if jmax < N
    jpt = jmax+1;
else
    jpt = jmax-(N-1)+2;
end;
fprintf('Maximum error in Jacobian = %.2e for variable %d', Emax, jmax);
fprintf(', s(jmax) = %.7f\n', s0(jmax));
fprintf('Corresponding point X(:,j), j = %d\n', jpt);
fprintf('Point X(:,j) = %.7f  %.7f  %.7f\n', X0(:,jpt))
figure(1); clf
plot(E, '.');
grid on
tstr = sprintf('Central difference errors in gradient of %s', fname);
title(tstr)

% Plot function value and slope along a line
d = zeros(size(s0)); d(jmax) = 1;
H = linspace(-0.5, 0.5, 41);
F = zeros(size(H));
DF = zeros(size(H));
for j = 1:length(H)
  hh = H(j);
  ss = s0 + hh*d;
  [r, A] = feval(fname, ss, L);
  F(j) = sum(r.*r); DF(j) = d*A'*r;
end;
figure(2); clf
subplot(2,1,1)
plot(H, F); grid on
subplot(2,1,2)
plot(H, DF); grid on

