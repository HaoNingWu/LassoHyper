%Four antipodal points on equtor.Spherical 1-design
% X=[1 0 -1 0;0 1 0 -1;0 0 0 0]
X=[1 0 -1 0;0 1 0 -1;0 0 0 0]
figure(21),spherepoint(X',1);alpha(0.3),shading('interp');
f  = sdobj(X, 1, 1)
%Spherical 1-design objective A_{L,N} with 4 points
%f = 0.000000e+000, Time = 0.00 secs
[G,detG]=Gram(X,1)
%detG =
  % 1.7764e-018
  %t=1,N=4=(t+1)^2,
  %but G is singular.
%since X is not a fundamental system
%16 points on equtor.Spherical 1-design
%t=1,N=16=(t+4)^2,
p=2*pi/10;
X1=[cos(p),sin(p),0;cos(2*p),sin(2*p),0;cos(3*p),sin(3*p),0;cos(4*p),sin(4*p),0;cos(5*p),sin(5*p),0;cos(6*p),sin(6*p),0;cos(7*p),sin(7*p),0;cos(8*p),sin(8*p),0;cos(9*p),sin(9*p),0;cos(10*p),sin(10*p),0];
% X1=[cos(p),sin(p),0;cos(2*p),sin(2*p),0;cos(3*p),sin(3*p),0;cos(4*p),sin(4*p),0;cos(5*p),sin(5*p),0;cos(6*p),sin(6*p),0;cos(7*p),sin(7*p),0;cos(8*p),sin(8*p),0;cos(9*p),sin(9*p),0;cos(10*p),sin(10*p),0;cos(11*p),sin(11*p),0;cos(12*p),sin(12*p),0;cos(13*p),sin(13*p),0;cos(14*p),sin(14*p),0;cos(15*p),sin(15*p),0;cos(16*p),sin(16*p),0];
figure(22),spherepoint(X1,1);alpha(0.3),shading('interp');
f1 = sdobj(X1', 1, 1)
[G1,detG1]=Gram(X1',1);
[G1,detG2]=Gram(X1',2);
[G1,detG3]=Gram(X1',3);
[G1,detG4]=Gram(X1',4);
detG1,detG2,detG3,detG4
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5
%Four points on equtor.not Spherical 1-design
X=[1 0 -1 0;0 1 0 -1;0 0 0 0]
figure(21),spherepoint(X',1);alpha(0.3),shading('interp');
f  = sdobj(X, 1, 1)
%Spherical 1-design objective A_{L,N} with 4 points
%f = 0.000000e+000, Time = 0.00 secs
[G,detG]=Gram(X,1)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5
p=2*pi/6;
X1=[cos(p),sin(p),0;cos(2*p),sin(2*p),0;cos(3*p),sin(3*p),0;cos(4*p),sin(4*p),0;cos(5*p),sin(5*p),0;cos(6*p),sin(6*p),0;];
figure(22),spherepoint(X1,1);alpha(0.3),shading('interp');
%%%%%%%%%%%5
p=2*pi/4;
X1=[cos(p),sin(p),0;cos(2*p),sin(2*p),0;cos(3*p),sin(3*p),0;cos(4*p),sin(4*p),0];
X1=[cos(p),sin(p),0;0,0,-1;cos(3*p),sin(3*p),0;0,0,1];
figure(22),spherepoint(X1);alpha(0.3),shading('interp');
[Y, Q, R] = normalize(X1)
