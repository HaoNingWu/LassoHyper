function [p, Dp, DDp] = gegen(n, z)
% [p, Dp, DDp] = gegen(n, z)
% Calculate the polynomial g(z) = (n+1)/(4*pi) * P^{(1,0}}_n (z)
% where P^{(1,0)}_n is the Jacobi polynomial and z is in [-1, 1]
% -- Input arguments --
% n   : Degree of the polynomial
% z   : Array of points in [-1, 1] where polynomial is to be evaluated
% -- Output arguments --
% p   : Array of the same size as z giving the polynomial values at z
% Dp  : Array of the same size as z giving derivatives of polynomial at z
% DDp : Array of the same size as z giving derivatives of polynomial at z
%     : If called with only one output argument the derivatives will not be calculated
%     : If called with only two output arguments only the first derivativ will be calculated

% Make sure elements of v are in [-1, 1]
%if min(z) < -1 | max(z) > 1
%disp('Jacobi: Input z being forced into [-1, 1]');
%z = max(z, -1);
%z = min(z, 1);
%end;

% Check if derivaitve required
% CalcDeriv = 0 for no derivtives, 1 for first derivative, 2 for first and second derivatives
CalcDeriv = nargout - 1;

% Recurrence for Jacobi polynomials
if n == 0
    
    p = ones(size(z));
    if CalcDeriv > 0
        Dp = zeros(size(z));
        if CalcDeriv > 1
            DDp = zeros(size(z));
        end;
    end;
    
elseif n == 1
    
    p = 1 + 3*z;
    if CalcDeriv > 0
        Dp = 3*ones(size(z));
        if CalcDeriv > 1
            DDp = zeros(size(z));
        end
    end;
    
 elseif n == 2
    
    p = -(3/2) + 3*z + (15/2)*z.^2;
    if CalcDeriv > 0
        Dp = 3 + 15*z;
        if CalcDeriv > 1
            DDp = 15*ones(size(z));
        end
    end;
    
   
else % n > 2
    
    % Initializing with p_1 and p_2
    % 3*prod(size(z)) flops for p1
    p0 = 1 + 3*z;
    % 5*prod(size(z)) flops for p1
    p1 = (-3/2) + 3*z + (15/2)*z.^2;
    if CalcDeriv > 0
        % An extra 3*prod(size(z)) flops for Dp0 and Dp1
        Dp0 = 3*ones(size(z));
        Dp1 = 3 + 15*z;
        if CalcDeriv > 1
            DDp0 = zeros(size(z));
            % An extra prod(size(z)) flops for DDp1
            DDp1 = 15*ones(size(z));
        end;
    end;
    
    % Start at degree 3 for n-2 iterations for polynomial of degree n
    for k = 3:n
        
        c1 = 1/(k*(2*k-1));
        c2 = (2*k+1)/k;
        c22 = 2*c2;
        c3 = -(2*k+1)/(2*k-1);
        
        % 6*prod(size(z)) flops per iterations for polynomial value
        zz = c2*z + c1;
        p = zz.*p1 + c3*p0;
        
        % An extra 5*prod(size(z)) flops per iteration for first deriviative
        if CalcDeriv > 0
            Dp = c2*p1 + zz.*Dp1 + c3*Dp0;
            % An extra 5*prod(size(z)) flops per iteration for second deriviative
            if CalcDeriv > 1
                DDp = c22*Dp1 + zz.*DDp1 + c3*DDp0;
                DDp0 = DDp1;
                DDp1 = DDp;
            end;
            Dp0 = Dp1;
            Dp1 = Dp;
        end;
        
        p0 = p1;
        p1 = p;
        
    end;
    
end;

S2norm = 4*pi;
p = p / S2norm;
if CalcDeriv > 0
    Dp = Dp / S2norm;
    if CalcDeriv > 1
        DDp = DDp / S2norm;
    end;
end;

