G=gramxddL(XX, L1);
G=G+ones(size(G));
a=4*pi;
G=G/a;







L1=11
G=gramxddL(XX, L1);
G=G+ones(size(G));
detG=det(G);

%__________________________L+3
% G3=gramxddL(XX, L3);
% det3G=det(G3);
%&---------------------
d=eig(G);
mind=min(abs(d))
prodd=prod(d)%------detG
logprod=log(prodd)