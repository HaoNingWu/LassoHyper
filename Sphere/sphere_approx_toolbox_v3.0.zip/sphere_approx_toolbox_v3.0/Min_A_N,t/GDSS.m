function GD=GDSS(XX)
%x is a matrix
% d=size(XX);
% d=d(2);
d=36;
for i=1:d;
    for j=1:d

a=dot(XX(:,i),XX(:,j));
b=1-2*log(1+sqrt((1-a)/2));

    end
end
GD=sqrt(b);
GD=(1/(2*sqrt(pi)*d))*GDS