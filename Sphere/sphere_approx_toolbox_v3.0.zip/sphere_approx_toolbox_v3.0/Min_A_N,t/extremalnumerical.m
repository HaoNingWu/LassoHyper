
 
 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%55
%  L=10;
% N=200
F=[];NN=[];MY=[];MY1=[];
MY0=[];MY10=[];
H=[];Angle=[];
XS=[];RS=[];
SY=[];
SY1=[];
FK=[];
FK1=[];
DiffY=[];DiffY1=[];
GDD=[]
    for t=5:7
%   t=19;
% s=50
%   for T=t-10:t+s;
%   t=t+3;
    N=(t+1)^2;
%    for N=220:2025
%  X0= ptsspb(N, 8, 9, 1.8);
  X0=Getextremal(t,N)
[f,N,XX,svdY,svdY1,minY,minY1,maxY,maxY1,ht,at,rs,Fanky,Fanky1]= Amin(X0,t);

% X0=Getextremal(t,N)
Y0=inmds(X0,t);
minY0=min(svd(Y0))
p=svd(Y0);
Y10=inmds(X0,t+1);
minY10=min(svd(Y10))
MY0(end+1,:)=minY0;
MY10(end+1,:)=minY10;
% SY(end+1,:)=svd(Y10);
ddd=sum(svd(inmds(XX,t)))-sum(svd(Y0));
ddd1=sum(svd(inmds(XX,t+1)))-sum(svd(Y10));
% Fanky
DiffY(end+1,:)=ddd
DiffY1(end+1,:)=ddd1
% FK(end+1,:)=Fanky;
% FK1(end+1,:)=Fanky1;
GD=GDS(XX');
GDD(end+1,:)=GD;
% end

% 
% [f,N,XX,minY,minY1,ht,at,s] = Amin(X0,t);
% 





%  for N=10:144
%  N=441
% z = 2*rand(1,N-1) - 1;
%     s0 = acos(z);
%     s0 = [s0 (2*pi)*rand(1,N-2)];
%     %s0 = ss;
%     X0 = s2cn(s0);
%     s0 = c2sn(X0);
%     fprintf('Pseudo-random intial points\n');
% 
% N=(L+2)^2
% [f,N,XX,minY,minY1,ht,at,s] = Amin(X0,L);
%   KMatrix1(end+1,:) = KArray1 ;
%             KMatrix2(end+1,:) = KArray2 ;
% F(end+1,:)=f;
% NN(end+1,:)=N;
% XS=[XS,XX];
% MY(end+1,:)=minY;
% MY1(end+1,:)=minY1;
% H(end+1,:)=ht;
% Angle(end+1,:)=at;
% RS(end+1,:)=rs;
 end
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  x=NN
  x=5:36
%   x=200:201;
figure(11),plot(x,abs(F),'*'),grid on,xlabel('Number of Points');title(''),
% ylabel('The vaule of final A_{N,19},   ','fontSize',16),
 set(gca, 'YScale', 'log')

%   figure(12),plot(x,MY,'*'),grid on,xlabel('Degree t');title('The behavior of minimal singular vaule of Y_{t}','fontSize',12),

%    figure(13),plot(x,MY1,'*'),grid on,xlabel('Number of Points');title('The behavior of minimal singular vaule of Y_{19+1}','fontSize',12)
figure(14),plot(x,H,'*'),grid on,xlabel('Number of Points');title('The behavior of mesh norm ','fontSize',16)
 hold on,plot(0.05)
     
figure(15),plot(x,Angle,'*'),grid on,xlabel('Number of Points');title('The behavior of minimal angle ','fontSize',16)
 
 figure(16),plot(x,RS,'*'),grid on,xlabel('Number of Points');title('The behavior of 2-norm of residual  ','fontSize',16), set(gca, 'YScale', 'log')
%%%%%%%%%%%%%%%%%%%%%%%%5
% figure(120),plot(x,MY,'*'),hold on,plot(x,MY0(1:36),'r^'),h = legend('initial','final',2);grid on,xlabel('Number of Points');title('The behavior of initial and final minimal singular vaule of Y_{19}','fontSize',12),
% % set(gca, 'YScale', 'log')
%    figure(130),plot(x,MY1,'*',x,MY10(1:36),'r^'),h = legend('initial','final',2),grid on,xlabel('Number of Points');title('The behavior of initial and final minimal singular vaule of Y_{19+1}','fontSize',12),
%    set(gca, 'YScale', 'log')


figure(120),plot(x,MY,'*','MarkerSize',8),hold on,plot(x,MY0,'r^','MarkerSize',8),h = legend('final','initial',12);grid on,xlabel('Number of Points');title(''),
% ylabel('The initial and final minimal singular vaules of Y_{19}','fontSize',16),
% set(gca, 'YScale', 'log')
% x=1:1000
   figure(130),plot(x,MY1,'*',x,MY10,'r^','MarkerSize',8),h = legend('final','initial',12),grid on,xlabel('Number of Points');title(''),
   ylabel('The initial and final minimal singular vaules of Y_{t+1}','fontSize',16),
%   hold on, plot(x,MY,'.','MarkerSize',8),hold on,plot(x,MY0,'r^','MarkerSize',8)
%  set(gca, 'YScale', 'log')
figure(140),plot(x,SY,'*',x,SY1,'r^','MarkerSize',8),h = legend('initial','final',12),grid on,xlabel('Number of Points');title(''),
  figure(150),plot(x,FK,'*',x,FK1,'r^','MarkerSize',8),h = legend('initial','final',12),grid on,xlabel('Number of Points');title(''),
  figure(160),plot(x,GDD,'*'),grid on,xlabel('degree');title('GD'),
% ylabel('The vaule of final A_{N,19},   ','fontSize',16),
 set(gca, 'YScale', 'log')
%%
% function X=Getextremal(tt,nn)
% % tt=T(j);
% tstr=sprintf('%.3f',tt/1e3);
% tstr=tstr(3:end);
% % nn=N(j)
% nstr=sprintf('%.5f',nn/1e5);
% nstr=nstr(3:end);
% % fstr=['load Points/MD/md' tstr '.' nstr];
% fstr=['load md/md' tstr '.' nstr];
% eval(fstr);
%  eval(['x=md' tstr '(:,1:3);']);
%  X=x';