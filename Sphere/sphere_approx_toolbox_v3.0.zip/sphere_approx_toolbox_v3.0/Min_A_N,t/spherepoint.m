function spherepoint(x,t)
sphere(300)
% shading('interp')
hold on,
% if t==1
    plot3(x(:,1),x(:,2),x(:,3),'r.','MarkerSize',28.3)
%      if t==2
%             plot3(x(:,1),x(:,2),x(:,3),'o','MarkerSize',15.7)
%         if t==3
%                 plot3(x(:,1),x(:,2),x(:,3),'^','MarkerSize',9.7)
%             end
%         end
% end
% t=size(x);
% y=t(1);


% camlight('headlight', 'infinite')