function [f, g, F] = normlagfg(s, X, n, GI, nrm, ipr)
% [f, g] = normintfg(s, X, n, GI, nrm)
% Calculate the norm specified by nrm of the Lagrangians 
% l = GI*g(x(s)), where GI = G^{-1},
% and its gradient w.r.t to the spherical coordinates s
% f can be minimized to get a local/global maximum of the norm over the sphere
% -- Input arguments --
% s = 2 by 1 array of spherical coordinates where f, g are to be evaluated
%     s = [theta; phi] where theta is in [0, pi] and phi is in [0, 2*pi)
% X = 3 by d array of interpolation points on the sphere
% GI = inverse of interpolation operator G, GI will be calculated if not passed
% nrm = 1   : f = - sum(abs(l)) - interpolation operator norm (default)
% nrm = 2   : f = - l'*l - sum of squares of Lagrangians
% nrm = Inf : f = - max(abs(l)) - infinity norm of lagrangians
% -- Output argument --
% f = value of norm of Lagrangians
% g = 2 by 1 array of gradient of f w.r.t s

t0 = cputime;

if nargin < 6
    ipr = 0;
end;
if nargin < 5
    nrm = 1;
end;
% Calculate GI = inv(G) if it is not provided
if nargin < 4
   G = gramxddn(X, n);
   GI = inv(G);
end;

% For interpolation d = (n+1)^2
d = size(X, 2);
if nargin < 3
    n = sqrt(d)-1;
end;
e = ones(3,1);
   
theta = s(1); phi = s(2);
ct = cos(theta); st = sin(theta);
cp = cos(phi); sp = sin(phi);
x = [st*cp; st*sp; ct];

% Initialize function value and gradient
f = 0;
g = zeros(size(s));

% Calculate 1 by d vector of angles between given points X and points x
Z = x' * X;

% For points on sphere (i.e. ||X(:,i)||_2 == 1, ||x(:,j)||_2 == 1)
% should have Z in [-1, 1]
Zmin = min(min(Z));
Zmax = max(max(Z));
if Zmin < -1 | Zmax > 1
   % Make sure elements of Z are in [-1, 1]
   Z = max(Z, -1);
   Z = min(Z, 1);
end;

% Recurrence for Legendre polynomials
P0 = ones(size(Z));
P1 = Z;
H = P0 + 3*Z;

% Information to accumulate derivatives of g(x) w.r.t. x
Q0 = zeros(3,d);
Q1 = X;
HD = 3*Q1;

for k = 2:n
   
   km = (2*k-1)/k;
   kk = (k-1)/k;
   kp = 2*k+1;
   
   P = km*Z.*P1 - kk*P0;
   H = H + kp*P;
   
   Q = km*(X.*P1(e,:) + Z(e,:).*Q1) - kk*Q0;
   HD = HD + kp*Q;
   
   P0 = P1;
   P1 = P;
   
   Q0 = Q1;
   Q1 = Q;
 
end;

% Normalize by surface area of sphere |S^2|
S2norm = 4*pi;
H = H / S2norm;
HD = HD / S2norm;

% Calculate inv(G)*H = GI*H and max e'*abs(LH)
F = H*GI;

if isinf(nrm)
    [f, imax] = max(abs(F)); f = -f;
    e = zeros(size(F)); e(imax) = sign(F(imax));
    gx = -HD*GI*e';
elseif nrm == 2
    f = - (F*F');
    gx = -2*(HD*GI*F');
else
    f = -sum(abs(F));
    gx = -HD*GI*sign(F)';
end;

g = [gx(1)*ct*cp + gx(2)*ct*sp - gx(3)*st; ...
    -gx(1)*st*sp + gx(2)*st*cp];

tc = cputime - t0;

if ipr > 0
    fprintf('\nCalculating the %d nrom of the Lagrangians function\n');
    fprintf('f = %.10f, g = [%.10f, %.10f]\n', f, g);
    fprintf(' Time = %.2f secs\n', tc);
end;
