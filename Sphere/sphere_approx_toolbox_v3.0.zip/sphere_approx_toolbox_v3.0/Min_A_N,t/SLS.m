function [r, A] = SLS(s, n, ipr)
% [r, A] = sfresid(s, n, ipr, isc)
% Calculate the residual r and Jacobian A for the residual form of
% the spherical n-design objective function
% s is the normalized spherical parametrization of the points
% if isc = 1 use the unormalized form of associated Legendre recurrence
% This is the default, but requires legendre1 rather than legendre
% if isc = 0 use the standard A & S associated Legendre scaling

% Number of points is m, number of variables s is 2m-3
% Dimension of space of polynomials of degee <= n is (n+1)^2

CalcJac = nargout > 1;

if nargin < 3
    ipr = 0;
end;
if nargin < 2
    fprintf('SFRESID: Error must have at least two input arguments\n');
    return;
end;

t0 = cputime;

X = s2cn(s);
m = size(X,2);
ns = length(s);

if CalcJac
    % Uses unormalized results from legendre1
    [Y, Yt, Yp] = inmds(X, n);
else
    % Uses unormalized results from legendre1
    Y = inmds(X, n);
end;

dn = size(Y,1);

%e = ones(m,1);
%r = Y*e;
r = sum(Y, 2);
r1 = r(1); r = r(2:dn);
%chk1 = r1 - m/sqrt(4*pi)
clear X Y s
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%jacobi matrix
if CalcJac
    %A = zeros(dn-1, ns);
    A = Yt(2:dn,2:m);
    clear Yt
    A = [A Yp(2:dn,3:m)];
    clear Yp
else
    A = [];
end;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5
tc = cputime - t0;
%%%%%%%%%%%%%%%%%
%  S=A'*r
%%%%%%%%%%%%%%%%%%%%%%
if ipr > 0
    fprintf('SFRESID: Spherical %d-design, Number of points m = %d\n', n, m);
    fprintf('||r||_inf = %.4e, Sum of squares = %.4e\n', norm(r, inf), sum(r.*r));
    fprintf('Calculation time for residual');
    if CalcJac
        fprintf(' and Jacobian');
    end;
    fprintf(' = %.2f secs\n', tc);
end;
if ipr > 1
    % Plot residuals
    figure(ipr); clf
    plot(r, '*');
    grid on
    nr = length(r);
    yl = get(gca, 'Ylim');
    hold on
    for j = 1:n
        np = (j+1)^2-1;
        deg = np*[1 1] + [0.5 0.5];
        plot(deg, yl, 'm-');
    end;
    hold off
    title('Residuals for spherical harmoic basis')
    xlabel('Degrees');
end;
