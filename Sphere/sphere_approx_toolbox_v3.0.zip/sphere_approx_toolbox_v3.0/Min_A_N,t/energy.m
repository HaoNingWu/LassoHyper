% function ene=energy(X)
%X is a matrix.m by 3
% [n,m]=size(X);
% e=0;
% ene=0
% for i=1:m
%     for j=i+1:m 
% %      ene=norm((X(i,:)-X(j,:)).^(-1));
% %       ene=norm((X(i)-X(j)).^(-1));
% ene=ene+1/norm(X(i,:)-X(j,:));
% % ene=ene+1/norm(X(:,i)-X(:,j));
% %     i,j
%     end
% % ene=e;
% %     ene=ene+e
% end
function ene=energy(x)
%x is a m by 3 matrix
ene=0
[m,t]=size(x);
for i=1:m
 for   j=i+1:m
    ene=ene+(1./(norm(x(i,:)-x(j,:))));
 end 
end

